# SpotQuest — Complete Test MVP

Android native spot-the-difference game with 20 playable levels, progression/unlock, local save, Daily Challenge, timer, hints, extra-time rewards and responsive hotspot mapping.

## Important
Reward buttons currently simulate successful rewarded ads so the game can be tested with no account or cost. Replace them with Google Mobile Ads SDK callbacks only after creating the publisher's own AdMob app/ad-unit IDs. Analytics should likewise be connected to the publisher's own Firebase project.

## Build free
Open in Android Studio and run on an Android phone. Or place this repository on GitHub and use the included `.github/workflows/build-apk.yml`; the artifact is `spotquest-debug-apk`.

## Content
The included 20 levels are functional test/MVP content generated from an original project visual and controlled local edits. Before public paid acquisition, replace repetitive test scenes with a diverse production scene pack while keeping the same level/hotspot architecture.
