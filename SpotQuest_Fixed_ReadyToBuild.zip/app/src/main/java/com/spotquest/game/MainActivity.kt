package com.spotquest.game

import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*

data class Hotspot(val x:Float,val y:Float,val radius:Float)
data class Level(val id:Int,val leftRes:Int,val rightRes:Int,val seconds:Int,val spots:List<Hotspot>)

class SpotImageView(context:android.content.Context):androidx.appcompat.widget.AppCompatImageView(context){
 var hotspots:List<Hotspot> = emptyList(); var found:Set<Int> = emptySet()
 private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=7f;color=Color.rgb(57,230,162)}
 init{scaleType=ScaleType.FIT_CENTER;adjustViewBounds=true}
 private fun imageRect():RectF{val d=drawable?:return RectF();val dw=d.intrinsicWidth.toFloat();val dh=d.intrinsicHeight.toFloat();val s=min(width/dw,height/dh);val w=dw*s;val h=dh*s;return RectF((width-w)/2f,(height-h)/2f,(width+w)/2f,(height+h)/2f)}
 fun normalized(px:Float,py:Float):Pair<Float,Float>?{val r=imageRect();if(!r.contains(px,py))return null;return Pair((px-r.left)/r.width(),(py-r.top)/r.height())}
 override fun onDraw(c:Canvas){super.onDraw(c);val r=imageRect();found.forEach{i->hotspots.getOrNull(i)?.let{h->c.drawCircle(r.left+h.x*r.width(),r.top+h.y*r.height(),h.radius*min(r.width(),r.height()),paint)}}}
}

class MainActivity:AppCompatActivity(){
 private val prefs by lazy{getSharedPreferences("spotquest",MODE_PRIVATE)}
 private val levels=listOf(
        Level(1, R.drawable.level_01_left, R.drawable.level_01_right, 75, listOf(Hotspot(0.200f,0.250f,.055f), Hotspot(0.420f,0.350f,.055f), Hotspot(0.630f,0.270f,.055f), Hotspot(0.320f,0.680f,.055f), Hotspot(0.780f,0.660f,.055f))),
        Level(2, R.drawable.level_02_left, R.drawable.level_02_right, 75, listOf(Hotspot(0.150f,0.480f,.055f), Hotspot(0.380f,0.220f,.055f), Hotspot(0.570f,0.520f,.055f), Hotspot(0.720f,0.340f,.055f), Hotspot(0.840f,0.730f,.055f))),
        Level(3, R.drawable.level_03_left, R.drawable.level_03_right, 75, listOf(Hotspot(0.240f,0.610f,.055f), Hotspot(0.460f,0.470f,.055f), Hotspot(0.660f,0.620f,.055f), Hotspot(0.760f,0.220f,.055f), Hotspot(0.880f,0.480f,.055f))),
        Level(4, R.drawable.level_04_left, R.drawable.level_04_right, 75, listOf(Hotspot(0.180f,0.310f,.055f), Hotspot(0.360f,0.580f,.055f), Hotspot(0.550f,0.240f,.055f), Hotspot(0.700f,0.700f,.055f), Hotspot(0.840f,0.390f,.055f))),
        Level(5, R.drawable.level_05_left, R.drawable.level_05_right, 75, listOf(Hotspot(0.200f,0.250f,.055f), Hotspot(0.420f,0.350f,.055f), Hotspot(0.630f,0.270f,.055f), Hotspot(0.320f,0.680f,.055f), Hotspot(0.780f,0.660f,.055f))),
        Level(6, R.drawable.level_06_left, R.drawable.level_06_right, 85, listOf(Hotspot(0.150f,0.480f,.055f), Hotspot(0.380f,0.220f,.055f), Hotspot(0.570f,0.520f,.055f), Hotspot(0.720f,0.340f,.055f), Hotspot(0.840f,0.730f,.055f))),
        Level(7, R.drawable.level_07_left, R.drawable.level_07_right, 85, listOf(Hotspot(0.240f,0.610f,.055f), Hotspot(0.460f,0.470f,.055f), Hotspot(0.660f,0.620f,.055f), Hotspot(0.760f,0.220f,.055f), Hotspot(0.880f,0.480f,.055f))),
        Level(8, R.drawable.level_08_left, R.drawable.level_08_right, 85, listOf(Hotspot(0.180f,0.310f,.055f), Hotspot(0.360f,0.580f,.055f), Hotspot(0.550f,0.240f,.055f), Hotspot(0.700f,0.700f,.055f), Hotspot(0.840f,0.390f,.055f))),
        Level(9, R.drawable.level_09_left, R.drawable.level_09_right, 85, listOf(Hotspot(0.200f,0.250f,.055f), Hotspot(0.420f,0.350f,.055f), Hotspot(0.630f,0.270f,.055f), Hotspot(0.320f,0.680f,.055f), Hotspot(0.780f,0.660f,.055f))),
        Level(10, R.drawable.level_10_left, R.drawable.level_10_right, 85, listOf(Hotspot(0.150f,0.480f,.055f), Hotspot(0.380f,0.220f,.055f), Hotspot(0.570f,0.520f,.055f), Hotspot(0.720f,0.340f,.055f), Hotspot(0.840f,0.730f,.055f))),
        Level(11, R.drawable.level_11_left, R.drawable.level_11_right, 95, listOf(Hotspot(0.240f,0.610f,.055f), Hotspot(0.460f,0.470f,.055f), Hotspot(0.660f,0.620f,.055f), Hotspot(0.760f,0.220f,.055f), Hotspot(0.880f,0.480f,.055f))),
        Level(12, R.drawable.level_12_left, R.drawable.level_12_right, 95, listOf(Hotspot(0.180f,0.310f,.055f), Hotspot(0.360f,0.580f,.055f), Hotspot(0.550f,0.240f,.055f), Hotspot(0.700f,0.700f,.055f), Hotspot(0.840f,0.390f,.055f))),
        Level(13, R.drawable.level_13_left, R.drawable.level_13_right, 95, listOf(Hotspot(0.200f,0.250f,.055f), Hotspot(0.420f,0.350f,.055f), Hotspot(0.630f,0.270f,.055f), Hotspot(0.320f,0.680f,.055f), Hotspot(0.780f,0.660f,.055f))),
        Level(14, R.drawable.level_14_left, R.drawable.level_14_right, 95, listOf(Hotspot(0.150f,0.480f,.055f), Hotspot(0.380f,0.220f,.055f), Hotspot(0.570f,0.520f,.055f), Hotspot(0.720f,0.340f,.055f), Hotspot(0.840f,0.730f,.055f))),
        Level(15, R.drawable.level_15_left, R.drawable.level_15_right, 95, listOf(Hotspot(0.240f,0.610f,.055f), Hotspot(0.460f,0.470f,.055f), Hotspot(0.660f,0.620f,.055f), Hotspot(0.760f,0.220f,.055f), Hotspot(0.880f,0.480f,.055f))),
        Level(16, R.drawable.level_16_left, R.drawable.level_16_right, 105, listOf(Hotspot(0.180f,0.310f,.055f), Hotspot(0.360f,0.580f,.055f), Hotspot(0.550f,0.240f,.055f), Hotspot(0.700f,0.700f,.055f), Hotspot(0.840f,0.390f,.055f))),
        Level(17, R.drawable.level_17_left, R.drawable.level_17_right, 105, listOf(Hotspot(0.200f,0.250f,.055f), Hotspot(0.420f,0.350f,.055f), Hotspot(0.630f,0.270f,.055f), Hotspot(0.320f,0.680f,.055f), Hotspot(0.780f,0.660f,.055f))),
        Level(18, R.drawable.level_18_left, R.drawable.level_18_right, 105, listOf(Hotspot(0.150f,0.480f,.055f), Hotspot(0.380f,0.220f,.055f), Hotspot(0.570f,0.520f,.055f), Hotspot(0.720f,0.340f,.055f), Hotspot(0.840f,0.730f,.055f))),
        Level(19, R.drawable.level_19_left, R.drawable.level_19_right, 105, listOf(Hotspot(0.240f,0.610f,.055f), Hotspot(0.460f,0.470f,.055f), Hotspot(0.660f,0.620f,.055f), Hotspot(0.760f,0.220f,.055f), Hotspot(0.880f,0.480f,.055f))),
        Level(20, R.drawable.level_20_left, R.drawable.level_20_right, 105, listOf(Hotspot(0.180f,0.310f,.055f), Hotspot(0.360f,0.580f,.055f), Hotspot(0.550f,0.240f,.055f), Hotspot(0.700f,0.700f,.055f), Hotspot(0.840f,0.390f,.055f)))
 )
 private var current=levels[0]; private val found=mutableSetOf<Int>(); private var remaining=0; private var timer:CountDownTimer?=null; private var daily=false
 private lateinit var timerText:TextView;private lateinit var progress:TextView;private lateinit var status:TextView;private lateinit var left:SpotImageView;private lateinit var right:SpotImageView
 override fun onCreate(b:Bundle?){super.onCreate(b);showHome()}
 private fun base()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,26,20,20);setBackgroundColor(Color.rgb(9,15,44));gravity=Gravity.CENTER_HORIZONTAL}
 private fun txt(s:String,z:Float=18f)=TextView(this).apply{text=s;textSize=z;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(8,9,8,9)}
 private fun btn(s:String,a:()->Unit)=Button(this).apply{text=s;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(38,51,111));setOnClickListener{a()}}
 private fun unlocked()=prefs.getInt("unlocked",1).coerceIn(1,levels.size)
 private fun showHome(){timer?.cancel();val r=base();r.addView(txt("SPOTQUEST",34f));r.addView(txt("Find the Difference",19f));r.addView(txt("20 levels • Daily Challenge",14f));r.addView(btn("CONTINUE · LEVEL ${unlocked()}"){startLevel(levels[unlocked()-1],false)},LinearLayout.LayoutParams(-1,-2).apply{topMargin=20});r.addView(btn("SELECT LEVEL"){showLevels()},LinearLayout.LayoutParams(-1,-2).apply{topMargin=10});r.addView(btn("DAILY CHALLENGE"){val day=(System.currentTimeMillis()/86400000L%levels.size).toInt();startLevel(levels[day],true)},LinearLayout.LayoutParams(-1,-2).apply{topMargin=10});r.addView(txt("Progress: ${prefs.getInt("completed",0)} / ${levels.size}",15f));setContentView(r)}
 private fun showLevels(){timer?.cancel();val s=ScrollView(this);val r=base();val u=unlocked();r.addView(txt("SELECT LEVEL",28f));levels.forEach{l->val locked=l.id>u;r.addView(btn(if(locked)"🔒 Level ${l.id}" else "Level ${l.id}"){if(!locked)startLevel(l,false)},LinearLayout.LayoutParams(-1,-2).apply{topMargin=6})};r.addView(btn("BACK"){showHome()},LinearLayout.LayoutParams(-1,-2).apply{topMargin=12});s.addView(r);setContentView(s)}
 private fun startLevel(l:Level,isDaily:Boolean){current=l;daily=isDaily;found.clear();remaining=l.seconds;val root=base();val h=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};h.addView(txt(if(isDaily)"Daily" else "Level ${l.id}",19f),LinearLayout.LayoutParams(0,-2,1f));progress=txt("○ ○ ○ ○ ○",20f);h.addView(progress,LinearLayout.LayoutParams(0,-2,1f));timerText=txt("",17f);h.addView(timerText);root.addView(h,LinearLayout.LayoutParams(-1,-2));left=gameImage(l.leftRes);right=gameImage(l.rightRes);root.addView(left,LinearLayout.LayoutParams(-1,0,1f).apply{topMargin=7});root.addView(right,LinearLayout.LayoutParams(-1,0,1f).apply{topMargin=7});status=txt("Find all 5 differences",15f);root.addView(status);val c=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};c.addView(btn("Hint · Ad"){rewardHint()},LinearLayout.LayoutParams(0,-2,1f));c.addView(btn("+30s · Ad"){rewardTime()},LinearLayout.LayoutParams(0,-2,1f).apply{marginStart=6});c.addView(btn("Restart"){startLevel(current,daily)},LinearLayout.LayoutParams(0,-2,1f).apply{marginStart=6});root.addView(c,LinearLayout.LayoutParams(-1,-2));setContentView(root);update();startTimer()}
 private fun gameImage(res:Int)=SpotImageView(this).apply{setImageResource(res);hotspots=current.spots;background=GradientDrawable().apply{setStroke(4,Color.rgb(56,71,156));cornerRadius=22f};setOnTouchListener{v,e->if(e.action==MotionEvent.ACTION_UP)tap(v as SpotImageView,e.x,e.y);true}}
 private fun tap(v:SpotImageView,px:Float,py:Float){val p=v.normalized(px,py)?:return;val hit=current.spots.indices.filter{it !in found}.minByOrNull{hypot((p.first-current.spots[it].x).toDouble(),(p.second-current.spots[it].y).toDouble())};if(hit!=null&&hypot((p.first-current.spots[hit].x).toDouble(),(p.second-current.spots[hit].y).toDouble())<current.spots[hit].radius*1.35){found.add(hit);status.text="Found ${found.size} of 5";update();if(found.size==5)complete()}else status.text="Not there — keep looking"}
 private fun update(){progress.text=(0..4).joinToString(" "){if(it in found)"●" else "○"};left.found=found;right.found=found;left.invalidate();right.invalidate();timerText.text=String.format("%02d:%02d",remaining/60,remaining%60)}
 private fun startTimer(){timer?.cancel();timer=object:CountDownTimer(remaining*1000L,1000){override fun onTick(ms:Long){remaining=ceil(ms/1000.0).toInt();update()};override fun onFinish(){remaining=0;update();AlertDialog.Builder(this@MainActivity).setTitle("Time Up").setMessage("Try again, or use +30 seconds when rewarded ads are connected.").setPositiveButton("Retry"){_,_->startLevel(current,daily)}.setNegativeButton("Home"){_,_->showHome()}.show()}}.start()}
 private fun rewardHint(){val i=current.spots.indices.firstOrNull{it !in found}?:return;found.add(i);status.text="Reward test → hint revealed";update();if(found.size==5)complete()}
 private fun rewardTime(){remaining+=30;status.text="Reward test → +30 seconds";startTimer()}
 private fun complete(){timer?.cancel();if(!daily){val old=unlocked();if(current.id>=old&&old<levels.size)prefs.edit().putInt("unlocked",old+1).apply();prefs.edit().putInt("completed",max(prefs.getInt("completed",0),current.id)).apply()};val next=current.id<levels.size;AlertDialog.Builder(this).setTitle("Level Complete!").setMessage("All 5 found with ${remaining}s remaining.").setPositiveButton(if(next&&!daily)"Next Level" else "Home"){_,_->if(next&&!daily)startLevel(levels[current.id],false)else showHome()}.setNegativeButton("Replay"){_,_->startLevel(current,daily)}.setCancelable(false).show()}
 @Deprecated("Deprecated in Java") override fun onBackPressed(){showHome()}
}
