# SpotQuest V2 Milestone 1

This build preserves the successful GitHub Actions build pipeline and upgrades the playable prototype.

## Included
- Premium dark navy/gold home screen and level selection.
- Safe system-bar spacing for modern Android phones.
- Level 1 rebuilt with five real visual differences (no debug shapes embedded in the image).
- Difference markers appear only after the player finds a difference.
- Hint uses a temporary dashed circle and does not auto-complete the difference.
- 0/5 progress, timer, pause, restart, teasing at 4/5, star result, progress persistence.
- Mystery Bonus teaser after every fifth level.
- Existing levels retained for continuity while V2 content is rebuilt progressively.

## Level 1 differences
1. Top-left hanging bulb state/color.
2. Sailboat sail color.
3. Right-side shutters color.
4. Right-side flower colors.
5. Chair cushion color.

## Debugging notes
- No permanent debug/test markers are shown to players.
- Touch hotspots are normalized to the displayed image area (FIT_CENTER), not raw screen coordinates.
- GitHub Actions workflow is intentionally unchanged from the successful baseline.
