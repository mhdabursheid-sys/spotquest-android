package com.spotquest.game

import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.*

data class Hotspot(val x: Float, val y: Float, val radius: Float)
data class Level(val id: Int, val leftRes: Int, val rightRes: Int, val seconds: Int, val spots: List<Hotspot>)

class SpotImageView(context: Context) : androidx.appcompat.widget.AppCompatImageView(context) {
    var hotspots: List<Hotspot> = emptyList()
    var found: Set<Int> = emptySet()
    var hinted: Int? = null
    private val foundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6f; color = Color.rgb(255, 197, 66)
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.WHITE
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    init { scaleType = ScaleType.FIT_CENTER; adjustViewBounds = true }
    private fun imageRect(): RectF {
        val d = drawable ?: return RectF()
        val dw = d.intrinsicWidth.toFloat(); val dh = d.intrinsicHeight.toFloat()
        if (dw <= 0 || dh <= 0 || width <= 0 || height <= 0) return RectF()
        val s = min(width / dw, height / dh); val rw = dw * s; val rh = dh * s
        return RectF((width-rw)/2f, (height-rh)/2f, (width+rw)/2f, (height+rh)/2f)
    }
    fun normalized(px: Float, py: Float): Pair<Float,Float>? {
        val r = imageRect(); if (r.width() <= 0 || !r.contains(px,py)) return null
        return Pair((px-r.left)/r.width(), (py-r.top)/r.height())
    }
    override fun onDraw(c: Canvas) {
        super.onDraw(c); val r = imageRect(); val base = min(r.width(), r.height())
        found.forEach { i -> hotspots.getOrNull(i)?.let { h ->
            c.drawCircle(r.left+h.x*r.width(), r.top+h.y*r.height(), h.radius*base, foundPaint)
        }}
        hinted?.takeIf { it !in found }?.let { i -> hotspots.getOrNull(i)?.let { h ->
            c.drawCircle(r.left+h.x*r.width(), r.top+h.y*r.height(), h.radius*base*1.35f, hintPaint)
        }}
    }
}

class MainActivity : AppCompatActivity() {
    private val navy = Color.rgb(5, 25, 48)
    private val navy2 = Color.rgb(8, 43, 72)
    private val card = Color.rgb(13, 48, 76)
    private val gold = Color.rgb(255, 190, 55)
    private val muted = Color.rgb(181, 198, 214)
    private val prefs by lazy { getSharedPreferences("spotquest", MODE_PRIVATE) }

    private val levels = listOf(
        Level(1,R.drawable.level_01_left,R.drawable.level_01_right,120,listOf(
            Hotspot(.050f,.113f,.052f), Hotspot(.281f,.455f,.055f), Hotspot(.865f,.331f,.070f),
            Hotspot(.865f,.615f,.075f), Hotspot(.885f,.805f,.090f))),
        Level(2,R.drawable.level_02_left,R.drawable.level_02_right,90,listOf(Hotspot(.15f,.48f,.055f),Hotspot(.38f,.22f,.055f),Hotspot(.57f,.52f,.055f),Hotspot(.72f,.34f,.055f),Hotspot(.84f,.73f,.055f))),
        Level(3,R.drawable.level_03_left,R.drawable.level_03_right,90,listOf(Hotspot(.24f,.61f,.055f),Hotspot(.46f,.47f,.055f),Hotspot(.66f,.62f,.055f),Hotspot(.76f,.22f,.055f),Hotspot(.88f,.48f,.055f))),
        Level(4,R.drawable.level_04_left,R.drawable.level_04_right,90,listOf(Hotspot(.18f,.31f,.055f),Hotspot(.36f,.58f,.055f),Hotspot(.55f,.24f,.055f),Hotspot(.70f,.70f,.055f),Hotspot(.84f,.39f,.055f))),
        Level(5,R.drawable.level_05_left,R.drawable.level_05_right,90,listOf(Hotspot(.20f,.25f,.055f),Hotspot(.42f,.35f,.055f),Hotspot(.63f,.27f,.055f),Hotspot(.32f,.68f,.055f),Hotspot(.78f,.66f,.055f)))
    )

    private var current = levels[0]; private val found = mutableSetOf<Int>()
    private var remaining = 0; private var timer: CountDownTimer? = null; private var daily = false
    private var hintIndex: Int? = null; private var hintsUsed = 0
    private lateinit var timerText: TextView; private lateinit var progressText: TextView
    private lateinit var statusText: TextView; private lateinit var left: SpotImageView; private lateinit var right: SpotImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = navy; window.navigationBarColor = navy
        showHome()
    }
    private fun dp(v:Int)=(v*resources.displayMetrics.density).roundToInt()
    private fun shape(color:Int, radius:Int=18, stroke:Int?=null)=GradientDrawable().apply {
        setColor(color); cornerRadius=dp(radius).toFloat(); stroke?.let{setStroke(dp(1),it)}
    }
    private fun text(s:String,size:Float=18f,color:Int=Color.WHITE,bold:Boolean=false)=TextView(this).apply {
        text=s; textSize=size; setTextColor(color); gravity=Gravity.CENTER_VERTICAL
        if(bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun button(s:String, primary:Boolean=false, action:()->Unit)=TextView(this).apply {
        text=s; textSize=17f; gravity=Gravity.CENTER; setTextColor(if(primary) Color.BLACK else Color.WHITE)
        setTypeface(typeface,android.graphics.Typeface.BOLD); background=shape(if(primary) gold else card,18,if(primary) null else Color.rgb(49,91,125))
        setPadding(dp(18),dp(15),dp(18),dp(15)); isClickable=true; isFocusable=true; setOnClickListener{action()}
    }
    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setBackgroundColor(navy); setPadding(dp(16),dp(12),dp(16),dp(16))
        ViewCompat.setOnApplyWindowInsetsListener(this){v,i->
            val b=i.getInsets(WindowInsetsCompat.Type.systemBars()); v.setPadding(dp(16),max(dp(12),b.top+dp(4)),dp(16),max(dp(16),b.bottom+dp(4))); i
        }
    }
    private fun unlocked()=prefs.getInt("unlocked",1).coerceIn(1,levels.size)

    private fun showHome(){
        timer?.cancel(); val scroll=ScrollView(this).apply{setBackgroundColor(navy)}; val r=root(); r.gravity=Gravity.CENTER_HORIZONTAL
        val hero=FrameLayout(this).apply{background=shape(navy2,26); clipToOutline=true}
        val img=ImageView(this).apply{setImageResource(R.drawable.level_01_left);scaleType=ImageView.ScaleType.CENTER_CROP;alpha=.58f}
        hero.addView(img,FrameLayout.LayoutParams(-1,dp(330)))
        val overlay=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(18),dp(28),dp(18),dp(22))}
        overlay.addView(text("SPOTQUEST",38f,Color.WHITE,true).apply{gravity=Gravity.CENTER})
        overlay.addView(text("Find the Difference",21f,Color.WHITE,true).apply{gravity=Gravity.CENTER})
        overlay.addView(text("Beautiful places. Hidden details.",14f,Color.WHITE).apply{gravity=Gravity.CENTER;setPadding(0,dp(5),0,dp(18))})
        overlay.addView(button("▶   PLAY",true){startLevel(levels[unlocked()-1],false)},LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(18),dp(92),dp(18),0)})
        hero.addView(overlay,FrameLayout.LayoutParams(-1,dp(330))); r.addView(hero,LinearLayout.LayoutParams(-1,dp(330)))
        val cont=button("Continue   ·   Level ${unlocked()}"){startLevel(levels[unlocked()-1],false)}
        r.addView(cont,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(14)})
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        row.addView(button("▦  Levels"){showLevels()},LinearLayout.LayoutParams(0,-2,1f).apply{marginEnd=dp(6)})
        row.addView(button("★  Daily"){val day=(System.currentTimeMillis()/86400000L%levels.size).toInt();startLevel(levels[day],true)},LinearLayout.LayoutParams(0,-2,1f).apply{marginStart=dp(6)})
        r.addView(row,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(12)})
        r.addView(text("Progress  ${prefs.getInt("completed",0)} / ${levels.size}",14f,muted).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(16)})
        scroll.addView(r); setContentView(scroll)
    }

    private fun showLevels(){
        timer?.cancel(); val scroll=ScrollView(this).apply{setBackgroundColor(navy)}; val r=root()
        val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        head.addView(button("‹"){showHome()},LinearLayout.LayoutParams(dp(54),-2)); head.addView(text("SELECT LEVEL",27f,Color.WHITE,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1f))
        r.addView(head); r.addView(text("Every 5 levels unlocks a Mystery Bonus",14f,muted).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(14)})
        val grid=GridLayout(this).apply{columnCount=2;alignmentMode=GridLayout.ALIGN_BOUNDS;useDefaultMargins=true}
        levels.forEach{l->
            val locked=l.id>unlocked(); val tile=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=shape(card,18,if(!locked&&l.id==unlocked()) gold else Color.rgb(40,75,105));setPadding(dp(8),dp(8),dp(8),dp(10));alpha=if(locked).55f else 1f}
            val im=ImageView(this).apply{setImageResource(l.leftRes);scaleType=ImageView.ScaleType.CENTER_CROP;background=shape(navy2,14);clipToOutline=true}
            tile.addView(im,LinearLayout.LayoutParams(-1,dp(130))); tile.addView(text(if(locked)"🔒  Level ${l.id}" else "Level ${l.id}",17f,Color.WHITE,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(7)})
            tile.addView(text(if(locked)"Locked" else if(l.id<prefs.getInt("unlocked",1))"★★★" else "Ready",13f,if(locked)muted else gold).apply{gravity=Gravity.CENTER})
            if(!locked)tile.setOnClickListener{startLevel(l,false)}
            grid.addView(tile,GridLayout.LayoutParams().apply{width=0;height=dp(190);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(dp(4),dp(4),dp(4),dp(4))})
        }
        r.addView(grid,LinearLayout.LayoutParams(-1,-2)); scroll.addView(r); setContentView(scroll)
    }

    private fun startLevel(level:Level,isDaily:Boolean){
        current=level; daily=isDaily; found.clear(); remaining=level.seconds; hintIndex=null; hintsUsed=0
        val r=root(); val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        header.addView(button("‹"){showHome()},LinearLayout.LayoutParams(dp(52),-2))
        header.addView(text(if(isDaily)"DAILY" else "Level ${level.id}",20f,Color.WHITE,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1f))
        timerText=text("",17f,Color.WHITE,true).apply{gravity=Gravity.CENTER;background=shape(navy2,20,Color.rgb(62,100,130));setPadding(dp(12),dp(8),dp(12),dp(8))};header.addView(timerText)
        r.addView(header)
        progressText=text("○  ○  ○  ○  ○",22f,gold,true).apply{gravity=Gravity.CENTER};r.addView(progressText,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(5);bottomMargin=dp(5)})
        left=gameImage(level.leftRes);right=gameImage(level.rightRes)
        r.addView(left,LinearLayout.LayoutParams(-1,0,1f).apply{bottomMargin=dp(6)});r.addView(right,LinearLayout.LayoutParams(-1,0,1f).apply{topMargin=dp(6)})
        statusText=text("Find all 5 differences",15f,Color.WHITE,true).apply{gravity=Gravity.CENTER};r.addView(statusText,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(6)})
        val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        controls.addView(button("💡  Hint"){useHint()},LinearLayout.LayoutParams(0,-2,1f).apply{marginEnd=dp(5)})
        controls.addView(button("Ⅱ  Pause"){pauseGame()},LinearLayout.LayoutParams(0,-2,1f).apply{marginStart=dp(5);marginEnd=dp(5)})
        controls.addView(button("↻  Restart"){startLevel(current,daily)},LinearLayout.LayoutParams(0,-2,1f).apply{marginStart=dp(5)})
        r.addView(controls,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(8)})
        setContentView(r); update(); startTimer()
    }
    private fun gameImage(res:Int)=SpotImageView(this).apply{
        setImageResource(res);hotspots=current.spots;background=shape(navy2,18,Color.rgb(44,89,122));clipToOutline=true
        setOnTouchListener{v,e->if(e.action==MotionEvent.ACTION_UP)tap(v as SpotImageView,e.x,e.y);true}
    }
    private fun tap(v:SpotImageView,px:Float,py:Float){
        val p=v.normalized(px,py)?:return
        val hit=current.spots.indices.filter{it !in found}.minByOrNull{hypot((p.first-current.spots[it].x).toDouble(),(p.second-current.spots[it].y).toDouble())}
        if(hit!=null && hypot((p.first-current.spots[hit].x).toDouble(),(p.second-current.spots[hit].y).toDouble()) < current.spots[hit].radius*1.45){
            found.add(hit); if(hintIndex==hit)hintIndex=null
            statusText.text=if(found.size==4)"ONE LEFT — can you spot it?" else "Nice!  ${found.size} / 5"
            update(); if(found.size==5)complete()
        } else statusText.text="Close — keep looking"
    }
    private fun update(){
        progressText.text=(0..4).joinToString("  "){if(it in found)"●" else "○"}
        left.found=found;right.found=found;left.hinted=hintIndex;right.hinted=hintIndex;left.invalidate();right.invalidate()
        timerText.text=String.format("%02d:%02d",remaining/60,remaining%60)
    }
    private fun startTimer(){
        timer?.cancel();timer=object:CountDownTimer(remaining*1000L,1000){
            override fun onTick(ms:Long){remaining=ceil(ms/1000.0).toInt();update()}
            override fun onFinish(){remaining=0;update();AlertDialog.Builder(this@MainActivity).setTitle("Time's up").setMessage("You were close. Try the level again.").setPositiveButton("Retry"){_,_->startLevel(current,daily)}.setNegativeButton("Home"){_,_->showHome()}.setCancelable(false).show()}
        }.start()
    }
    private fun useHint(){
        val i=current.spots.indices.firstOrNull{it !in found}?:return;hintIndex=i;hintsUsed++;statusText.text="Hint: look inside the dashed circle";update()
        Handler(Looper.getMainLooper()).postDelayed({if(hintIndex==i){hintIndex=null;update()}},3500)
    }
    private fun pauseGame(){
        timer?.cancel();AlertDialog.Builder(this).setTitle("Paused").setMessage("Take your time.").setPositiveButton("Resume"){_,_->startTimer()}.setNegativeButton("Home"){_,_->showHome()}.setCancelable(false).show()
    }
    private fun complete(){
        timer?.cancel(); if(!daily){val old=unlocked();if(current.id>=old&&old<levels.size)prefs.edit().putInt("unlocked",old+1).apply();prefs.edit().putInt("completed",max(prefs.getInt("completed",0),current.id)).apply()}
        val stars=when{hintsUsed==0&&remaining>current.seconds/2->3;hintsUsed<=1->2;else->1};val bonus=!daily&&current.id%5==0
        AlertDialog.Builder(this).setTitle("${"★".repeat(stars)}  Level Complete!").setMessage("Time left: ${remaining}s\nHints used: $hintsUsed${if(bonus)"\n\n🎁 MYSTERY BONUS UNLOCKED" else if(!daily)"\n\nNext level is waiting…" else ""}")
            .setPositiveButton(if(bonus)"Bonus Preview" else if(!daily&&current.id<levels.size)"Next Level" else "Home"){_,_->
                if(bonus)showBonus() else if(!daily&&current.id<levels.size)startLevel(levels[current.id],false) else showHome()}
            .setNegativeButton("Home"){_,_->showHome()}.setCancelable(false).show()
    }
    private fun showBonus(){
        val r=root();r.gravity=Gravity.CENTER
        r.addView(text("🎁",72f).apply{gravity=Gravity.CENTER})
        r.addView(text("MYSTERY BONUS",30f,gold,true).apply{gravity=Gravity.CENTER})
        r.addView(text("Every 5 levels brings a quick surprise challenge.\nMemory • XO • Quick Quiz • What Changed?",17f,Color.WHITE).apply{gravity=Gravity.CENTER;textAlignment=View.TEXT_ALIGNMENT_CENTER},LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(20)})
        r.addView(text("Bonus mini-games are staged for the next V2 milestone.",14f,muted).apply{gravity=Gravity.CENTER;textAlignment=View.TEXT_ALIGNMENT_CENTER},LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(18)})
        r.addView(button("Continue",true){showHome()},LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(28)})
        setContentView(r)
    }
    @Deprecated("Deprecated in Java") override fun onBackPressed(){showHome()}
    override fun onDestroy(){timer?.cancel();super.onDestroy()}
}
